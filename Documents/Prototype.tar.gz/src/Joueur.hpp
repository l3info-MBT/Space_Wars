#ifndef JOUEUR_HPP_
#define JOUEUR_HPP_

#include <iostream>
#include <SFML/Graphics.hpp>

//#include "type.h"

class Joueur
{
private:/*
  int nbVie;
  int enVie;*/
public:
sf::Texture vaisseau;
sf::Sprite ajouterVaisseau(sf::Sprite sp, float posX, float posY);/*
int getEnVie();
int getNbVie();
void setNbVie(int a);*/
};

#endif
