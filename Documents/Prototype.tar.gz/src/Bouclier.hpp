#ifndef BOUCLIER_HPP_
#define BOUCLIER_HPP_

#include <iostream>
#include <SFML/Graphics.hpp>

//#include "type.h"

class Bouclier
{
private:
public:
  sf::Texture bouclier;
  sf::Sprite ajouterBouclier(sf::Sprite sp, float posBouclierX, float posBouclierY);
};

#endif
