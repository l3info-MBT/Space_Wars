#ifndef ALIEN_HPP_
#define ALIEN_HPP_

#include <iostream>
#include <SFML/Graphics.hpp>

//#include "type.h"

class Alien
{
private:
public:
  sf::Texture alien;
  sf::Sprite ajouterAlien1_1(sf::Sprite sp, float posAlienX, float posAlienY);
  sf::Sprite ajouterAlien1_2(sf::Sprite sp, float posAlienX, float posAlienY);
  sf::Sprite ajouterAlien2_1(sf::Sprite sp, float posAlienX, float posAlienY);
  sf::Sprite ajouterAlien2_2(sf::Sprite sp, float posAlienX, float posAlienY);
  sf::Sprite ajouterAlien3_1(sf::Sprite sp, float posAlienX, float posAlienY);
  sf::Sprite ajouterAlien3_2(sf::Sprite sp, float posAlienX, float posAlienY);
  sf::Sprite supprimerAlien(sf::Sprite sp);
};

#endif
